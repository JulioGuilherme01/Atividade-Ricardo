package main

import (
	"fmt"
)

type ContaBancaria struct {
	titular string
	saldo   float64
}

func (c *ContaBancaria) Deposito(valor float64) {
	if valor > 0 {
		c.saldo += valor
	} else {
		fmt.Println("Valor inválido para depósito.")
	}
}

func (c *ContaBancaria) Sacar(valor float64) {
	if valor > 0 && valor <= c.saldo {
		c.saldo -= valor
	} else {
		fmt.Println("Valor inválido para saque.")
	}
}

func (c ContaBancaria) GetSaldo() float64 {
	return c.saldo
}

func main() {

	conta := ContaBancaria{titular: "João Silva"}

	fmt.Println("Saldo inicial:", conta.GetSaldo())

	conta.Deposito(100.0)
	fmt.Println("Após depósito de R$100,00:", conta.GetSaldo())

	conta.Deposito(50.0)
	fmt.Println("Após depósito de R$50,00:", conta.GetSaldo())

	conta.Sacar(30.0)
	fmt.Println("Após saque de R$30,00:", conta.GetSaldo())

	conta.Sacar(150.0)
	fmt.Println("Após tentativa de saque de R$150,00:", conta.GetSaldo())
}
