package main

type Empresa struct {
	Empregados []Empregado
}

type Empregado struct {
	Nome    string
	Cargo   string
	Salario float64
}
