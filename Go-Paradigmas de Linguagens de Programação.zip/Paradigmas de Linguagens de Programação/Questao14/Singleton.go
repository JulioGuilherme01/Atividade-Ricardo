package main

import (
	"fmt"
	"sync"
)

type Configuracao struct {
	configuracao map[string]string
}

var (
	instancia *Configuracao
	once      sync.Once
)

// Função para obter a instância da classe Configuracao
func GetInstancia() *Configuracao {
	once.Do(func() {
		instancia = &Configuracao{
			configuracao: make(map[string]string),
		}
	})
	return instancia
}

func (c *Configuracao) SetConfig(chave, valor string) {
	c.configuracao[chave] = valor
}

func (c *Configuracao) GetConfig(chave string) string {
	return c.configuracao[chave]
}

func main() {
	config1 := GetInstancia()
	config1.SetConfig("url", "https://youtube.com")

	config2 := GetInstancia()
	fmt.Println(config2.GetConfig("url"))
	fmt.Println(config1 == config2)
}
