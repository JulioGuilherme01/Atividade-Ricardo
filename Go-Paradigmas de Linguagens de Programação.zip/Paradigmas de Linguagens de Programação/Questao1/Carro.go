package main

import "fmt"

type Carro struct {
	modelo string
	marca  string
	cor    string
	ano    int
}

func (c Carro) exibirInformacoes() string {
	return fmt.Sprintf("Modelo: %s, Marca: %s, Cor: %s, Ano: %d", c.modelo, c.marca, c.cor, c.ano)
}

func main() {
	carro1 := Carro{"Civic", "Honda", "Preto", 2020}
	carro2 := Carro{"Fusca", "Volkswagen", "Branco", 1976}
	carro3 := Carro{"Model S", "Tesla", "Vermelho", 2022}

	fmt.Println(carro1.exibirInformacoes())
	fmt.Println(carro2.exibirInformacoes())
	fmt.Println(carro3.exibirInformacoes())
}
