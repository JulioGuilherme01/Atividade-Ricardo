package main

type Motor struct{}

type Carro struct {
	Motor Motor
}
