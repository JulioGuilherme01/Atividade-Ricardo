package main

import "fmt"

type Carro struct {
	modelo     string
	marca      string
	cor        string
	ano        int
	velocidade int
}

func (c Carro) exibirInformacoes() string {
	return fmt.Sprintf("Modelo: %s, Marca: %s, Cor: %s, Ano: %d", c.modelo, c.marca, c.cor, c.ano)
}

func (c *Carro) acelerar() {
	c.velocidade += 10
	fmt.Printf("%s Acelerando...\n", c.modelo)
}

func (c *Carro) desacelerar() {
	if c.velocidade >= 10 {
		c.velocidade -= 10
	} else {
		c.velocidade = 0
	}
	fmt.Printf("%s Desacelerando...\n", c.modelo)
}

func (c Carro) exibirVelocidade() string {
	return fmt.Sprintf("Velocidade: %d", c.velocidade)
}

func main() {

	carro1 := Carro{"Civic", "Honda", "Preto", 2020, 0}
	carro2 := Carro{"Fusca", "Volkswagen", "Branco", 1976, 0}
	carro3 := Carro{"Model S", "Tesla", "Vermelho", 2022, 0}

	fmt.Println(carro1.exibirInformacoes())
	fmt.Println(carro2.exibirInformacoes())
	fmt.Println(carro3.exibirInformacoes())

	carro1.acelerar()
	carro1.acelerar()
	carro2.acelerar()
	carro2.desacelerar()
	carro3.acelerar()

	fmt.Println(carro1.exibirVelocidade())
	fmt.Println(carro2.exibirVelocidade())
	fmt.Println(carro3.exibirVelocidade())
}
