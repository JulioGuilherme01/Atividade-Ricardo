package main

type Escola struct {
	Professores []Professor
}

type Professor struct{}
