package main

import (
	"fmt"
	"log"
)

// Matematica struct
type Matematica struct{}

// Método para calcular o fatorial
func (m Matematica) Fatorial(n int) int {
	if n < 0 {
		log.Fatal("O fatorial não está definido para números negativos.")
	}
	if n == 0 || n == 1 {
		return 1
	}
	resultado := 1
	for i := 2; i <= n; i++ {
		resultado *= i
	}
	return resultado
}

func main() {
	m := Matematica{}
	fmt.Println(m.Fatorial(5))
	fmt.Println(m.Fatorial(2))
}
