package main

import "fmt"

type Funcionario interface {
	calcularSalario() float64
}

type FuncionarioAssalariado struct {
	salarioFixo float64
}

type FuncionarioHorista struct {
	horasTrabalhadas float64
	valorHora        float64
}

func (f FuncionarioAssalariado) calcularSalario() float64 {
	return f.salarioFixo
}

func (f FuncionarioHorista) calcularSalario() float64 {
	return f.horasTrabalhadas * f.valorHora
}

func main() {
	fAssalariado := FuncionarioAssalariado{salarioFixo: 100}
	fHorista := FuncionarioHorista{horasTrabalhadas: 7, valorHora: 80}

	fmt.Println(fAssalariado.calcularSalario())
	fmt.Println(fHorista.calcularSalario())
}
