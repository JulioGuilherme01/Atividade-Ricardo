package main

import "fmt"

func somarDois(a int, b int) int {
	return a + b
}

func somarTres(a int, b int, c int) int {
	return a + b + c
}

func main() {
	fmt.Println("Soma de 2 números:", somarDois(5, 10))
	fmt.Println("Soma de 3 números:", somarTres(5, 10, 15))
}
