package main

import (
	"fmt"
)

type SaldoInsuficienteError struct {
	Valor float64
}

func (e *SaldoInsuficienteError) Error() string {
	return fmt.Sprintf("Saldo insuficiente para o saque de: %.2f", e.Valor)
}

type ContaBancaria struct {
	saldo float64
}

func NewContaBancaria(saldoInicial float64) *ContaBancaria {
	return &ContaBancaria{saldo: saldoInicial}
}

func (c *ContaBancaria) Sacar(valor float64) error {
	if valor > c.saldo {
		return &SaldoInsuficienteError{Valor: valor}
	}
	c.saldo -= valor
	return nil
}

func main() {
	conta := NewContaBancaria(100.0)

	if err := conta.Sacar(150.0); err != nil {
		fmt.Println(err)
	}
}
