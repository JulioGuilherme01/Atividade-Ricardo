package main

import (
	"fmt"
)

type Animal interface {
	som() string
}

type Cachorro struct{}

func (c Cachorro) som() string {
	return "Au Au"
}

type Gato struct{}

func (g Gato) som() string {
	return "Miau"
}

func main() {
	var animals []Animal
	animals = append(animals, Cachorro{}, Gato{})

	for _, animal := range animals {
		fmt.Println(animal.som())
	}
}
