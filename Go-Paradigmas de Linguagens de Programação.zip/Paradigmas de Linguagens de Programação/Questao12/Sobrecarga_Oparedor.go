package main

import (
	"fmt"
)

type Produto struct {
	nome  string
	preco float64
}

func (p Produto) somar(outro Produto) Produto {
	return Produto{nome: p.nome + " + " + outro.nome, preco: p.preco + outro.preco}
}

func (p Produto) String() string {
	return fmt.Sprintf("%s: R$ %.2f", p.nome, p.preco)
}

func main() {
	produto1 := Produto{nome: "Produto A", preco: 50.00}
	produto2 := Produto{nome: "Produto B", preco: 30.00}
	produtoTotal := produto1.somar(produto2)

	fmt.Println(produtoTotal)
}
