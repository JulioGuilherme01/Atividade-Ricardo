package Questão2;

public class Carro {
    private String modelo;
    private String marca;
    private String cor;
    private int ano;
    private int velocidade;

    public int getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }

    public Carro(String modelo, String marca, String cor, int ano) {
        this.modelo = modelo;
        this.marca = marca;
        this.cor = cor;
        this.ano = ano;
        this.velocidade = 0;
    }

    public void acelerar() {
        velocidade += 10;
        setVelocidade(velocidade);
        System.out.println(this.modelo+" Acelerando...");

    }
    public void desacelerar() {
        if (velocidade >= 10) {
            velocidade -= 10;
        } else {
            velocidade = 0;
        }
        setVelocidade(velocidade);
        System.out.println(this.modelo+" Desacelerando...");
    }

    public String exibirInformacoes() {
        return "Modelo: " + modelo + ", Marca: " + marca + ", Cor: " + cor + ", Ano: " + ano;
    }

    public String exibirVelocidade() {
        return "Velocidade: "+ velocidade;
    }



}
