package Questão7;

import java.util.ArrayList;
import java.util.List;

public class Escola {
    private List<Professor> professores = new ArrayList<>();

    public void adicionarProfessor(Professor professor) {
        professores.add(professor);
    }
}
