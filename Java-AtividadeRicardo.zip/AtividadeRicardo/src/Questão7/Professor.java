package Questão7;

public class Professor {
    private String nome;
    private int idade;
}
