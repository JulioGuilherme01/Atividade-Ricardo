package Questão13;

public class Main {
    public static void main(String[] args) {
        System.out.println(Matematica.fatorial(5));
        System.out.println(Matematica.fatorial(2));
    }
}
