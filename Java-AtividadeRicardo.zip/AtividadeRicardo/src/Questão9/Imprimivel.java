package Questão9;

public interface Imprimivel {
    void imprimir();
}

