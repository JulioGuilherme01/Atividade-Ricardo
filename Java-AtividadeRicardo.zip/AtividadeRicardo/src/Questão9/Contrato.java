package Questão9;

public class Contrato implements Imprimivel{
    @Override
    public void imprimir() {
        System.out.println("Imprimindo contrato");
    }
}
