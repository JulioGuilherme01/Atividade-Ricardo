package Questão14;
import java.util.HashMap;
import java.util.Map;
public class Configuracao {
    private static Configuracao instancia;
    private Map<String, String> configuracao;


    private Configuracao() {
        configuracao = new HashMap<>();
    }


    public static Configuracao getInstancia() {
        if (instancia == null) {
            instancia = new Configuracao();
        }
        return instancia;
    }

    public void setConfig(String chave, String valor) {
        configuracao.put(chave, valor);
    }

    public String getConfig(String chave) {
        return configuracao.get(chave);
    }

}
