package Questão14;

public class Main {
    public static void main(String[] args) {
        Configuracao config1 = Configuracao.getInstancia();
        config1.setConfig("url", "https://youtube.com");

        Configuracao config2 = Configuracao.getInstancia();
        System.out.println(config2.getConfig("url"));
        System.out.println(config1 == config2);
    }
}
