package questão1;

public class Main {
    public static void main(String[] args) {

        Carro carro1 = new Carro("Civic", "Honda", "Preto", 2020);
        Carro carro2 = new Carro("Fusca", "Volkswagen", "Branco", 1976);
        Carro carro3 = new Carro("Model S", "Tesla", "Vermelho", 2022);


        System.out.println(carro1.exibirInformacoes());
        System.out.println(carro2.exibirInformacoes());
        System.out.println(carro3.exibirInformacoes());
    }
}