package Questão4;

public abstract class Animal {
    public abstract String emitirSom();

}
