package Questão4;

public class Main {
    public static void main(String[] args) {
        Animal cachorro = new Cachorro();
        Animal gato = new Gato();

        System.out.println("Cachorro faz: " + cachorro.emitirSom());
        System.out.println("Gato faz: " + gato.emitirSom());
    }
}
