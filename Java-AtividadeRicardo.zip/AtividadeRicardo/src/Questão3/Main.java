package Questão3;

public class Main {
    public static void main(String[] args) {
        ContaBancaria conta = new ContaBancaria("João Silva");


        System.out.println("Saldo inicial: " + conta.getSaldo());


        conta.deposito(100.0);
        System.out.println("Após depósito de R$100,00: " + conta.getSaldo());

        conta.deposito(50.0);
        System.out.println("Após depósito de R$50,00: " + conta.getSaldo());


        conta.sacar(30.0);
        System.out.println("Após saque de R$30,00: " + conta.getSaldo());


        conta.sacar(150.0);
        System.out.println("Após tentativa de saque de R$150,00: " + conta.getSaldo());

    }
}
