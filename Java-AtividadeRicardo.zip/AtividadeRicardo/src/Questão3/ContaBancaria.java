package Questão3;

public class ContaBancaria {
    private double saldo;
    private String titular;

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public ContaBancaria(String titular) {
        this.titular = titular;
    }

    public void deposito(double valor) {
        if (valor > 0) {
            this.saldo += valor;
        }else {
            System.out.println("Valor invalido");
        }
    }
    public void sacar(double valor) {
        if (valor > 0 && this.saldo >= valor) {
            this.saldo -= valor;
        }else {
            System.out.println("Valor invalido");
        }

    }
}
