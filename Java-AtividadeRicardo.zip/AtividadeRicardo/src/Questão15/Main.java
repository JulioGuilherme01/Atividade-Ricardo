package Questão15;

public class Main {
    public static void main(String[] args) {
        ContaBancaria conta = new ContaBancaria(100.0);

        try {
            conta.sacar(150.0);
        } catch (SaldoInsuficienteEx e) {
            System.out.println(e.getMessage());
        }
    }
}

