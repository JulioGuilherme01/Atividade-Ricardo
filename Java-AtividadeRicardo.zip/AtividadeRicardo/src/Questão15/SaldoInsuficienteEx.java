package Questão15;

public class SaldoInsuficienteEx extends Exception{
    public SaldoInsuficienteEx(String mensagem) {
        super(mensagem);
    }
}
