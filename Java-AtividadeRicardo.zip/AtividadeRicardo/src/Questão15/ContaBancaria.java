package Questão15;

public class ContaBancaria {
    private double saldo;

    public ContaBancaria(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    public void sacar(double valor) throws SaldoInsuficienteEx {
        if (valor > saldo) {
            throw new SaldoInsuficienteEx("Saldo insuficiente para o saque de: " + valor);
        }
        saldo -= valor;
    }

    public double getSaldo() {
        return saldo;
    }
}
