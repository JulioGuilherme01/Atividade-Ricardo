package Questão10;

public class Main {
    public static void main(String[] args) {
        Calculadora calc = new Calculadora();

        System.out.println(calc.somar(10,5));
        System.out.println(calc.somar(12,3,1));
    }
}
