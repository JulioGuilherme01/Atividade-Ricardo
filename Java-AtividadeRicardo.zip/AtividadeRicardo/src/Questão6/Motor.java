package Questão6;

public class Motor {
    private String modelo;
    private int cilindradas;
}
