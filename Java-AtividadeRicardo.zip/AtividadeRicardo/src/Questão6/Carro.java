package Questão6;

public class Carro {
    private Motor motor;

    public Carro(Motor motor) {
        this.motor = motor;
    }
}
