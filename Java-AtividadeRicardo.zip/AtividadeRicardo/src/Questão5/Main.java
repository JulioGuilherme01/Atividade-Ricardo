package Questão5;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void emitirSons(List<Animal> animais) {
        for (Animal animal : animais) {
            System.out.println(animal.emitirSom());
        }
    }
    public static void main(String[] args) {
        List<Animal> animais = new ArrayList<>();
        animais.add(new Cachorro());
        animais.add(new Gato());

        
        emitirSons(animais);
    }
}
