package Questão5;

public class Gato extends Animal {

    @Override
    public String emitirSom() {
        return "Miau";
    }
}
