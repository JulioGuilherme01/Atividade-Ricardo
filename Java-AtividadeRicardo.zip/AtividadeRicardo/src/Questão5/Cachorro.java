package Questão5;

public class Cachorro extends Animal {
    @Override
    public String emitirSom() {
        return "Au Au";
    }
}
