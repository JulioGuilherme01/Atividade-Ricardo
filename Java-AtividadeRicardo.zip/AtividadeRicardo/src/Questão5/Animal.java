package Questão5;

public abstract class Animal {
    public abstract String emitirSom();

}
