package Questão11;

public class FuncionarioHorista extends Funcionario{
    private double horasTrabalhadas;
    private double valorHora;

    public FuncionarioHorista(double horasTrabalhadas, double valorHora) {
        this.horasTrabalhadas = horasTrabalhadas;
        this.valorHora = valorHora;
    }

    public double calcularSalario() {
        return horasTrabalhadas * valorHora;
    }
}
