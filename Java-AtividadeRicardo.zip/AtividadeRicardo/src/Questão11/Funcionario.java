package Questão11;

public abstract class Funcionario {
    abstract double calcularSalario();
}
