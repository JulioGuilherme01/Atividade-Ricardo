package Questão11;

public class FuncionarioAssalariado extends Funcionario{
    private double salarioFixo;

    public FuncionarioAssalariado(double salarioFixo) {
        this.salarioFixo = salarioFixo;
    }

    public double calcularSalario() {
        return salarioFixo;
    }
}
