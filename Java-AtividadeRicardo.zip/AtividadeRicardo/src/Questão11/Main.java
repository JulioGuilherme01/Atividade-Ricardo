package Questão11;

public class Main {
    public static void main(String[] args) {
        FuncionarioAssalariado f = new FuncionarioAssalariado(100);
        FuncionarioHorista fh = new FuncionarioHorista(7,80);

        System.out.println(f.calcularSalario());
        System.out.println(fh.calcularSalario());
    }
}
