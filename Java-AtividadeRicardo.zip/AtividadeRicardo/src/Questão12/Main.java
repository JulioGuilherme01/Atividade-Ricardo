package Questão12;

public class Main {
    public static void main(String[] args) {
        Produto produto1 = new Produto("Produto A", 50.00);
        Produto produto2 = new Produto("Produto B", 30.00);
        Produto produtoTotal = produto1.somar(produto2);

        System.out.println(produtoTotal);
    }
}
