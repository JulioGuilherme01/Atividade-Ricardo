package Questão8;

import java.util.ArrayList;
import java.util.List;

public class Empresa {
    private List<Empregado> empregados = new ArrayList<>();

    public void adicionarEmpregado(Empregado empregado) {
        empregados.add(empregado);
    }
}
