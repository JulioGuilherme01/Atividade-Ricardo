package Questão8;

public class Empregado {
    private String nome;
    private String cargo;
    private double salario;
}
