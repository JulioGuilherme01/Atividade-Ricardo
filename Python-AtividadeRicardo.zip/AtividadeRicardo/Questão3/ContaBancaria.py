class ContaBancaria:
    def __init__(self, titular):
        self._saldo = 0.0
        self._titular = titular

    def deposito(self, valor):
        if valor > 0:
            self._saldo += valor
        else:
            print("Valor inválido para depósito.")

    def sacar(self, valor):
        if valor > 0 and valor <= self._saldo:
            self._saldo -= valor
        else:
            print("Valor inválido para saque.")

    def get_saldo(self):
        return self._saldo


def main():
    
    conta = ContaBancaria("João Silva")


    print("Saldo inicial:", conta.get_saldo())


    conta.deposito(100.0)
    print("Após depósito de R$100,00:", conta.get_saldo())

    conta.deposito(50.0)
    print("Após depósito de R$50,00:", conta.get_saldo())


    conta.sacar(30.0)
    print("Após saque de R$30,00:", conta.get_saldo())


    conta.sacar(150.0)
    print("Após tentativa de saque de R$150,00:", conta.get_saldo())


if __name__ == "__main__":
    main()
