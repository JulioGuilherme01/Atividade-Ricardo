class Motor:
    pass

class Carro:
    def __init__(self, motor):
        self.motor = motor
