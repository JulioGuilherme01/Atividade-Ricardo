class Carro:
    def __init__(self, modelo, marca, cor, ano):
        self._modelo = modelo
        self._marca = marca
        self._cor = cor
        self._ano = ano

    def exibir_informacoes(self):
        return f"Modelo: {self._modelo}, Marca: {self._marca}, Cor: {self._cor}, Ano: {self._ano}"


if __name__ == "__main__":
    carro1 = Carro("Civic", "Honda", "Preto", 2020)
    carro2 = Carro("Fusca", "Volkswagen", "Branco", 1976)
    carro3 = Carro("Model S", "Tesla", "Vermelho", 2022)

    print(carro1.exibir_informacoes())
    print(carro2.exibir_informacoes())
    print(carro3.exibir_informacoes())
