class SaldoInsuficienteException(Exception):
    pass

class ContaBancaria:
    def __init__(self, saldo_inicial):
        self.saldo = saldo_inicial

    def sacar(self, valor):
        if valor > self.saldo:
            raise SaldoInsuficienteException(f'Saldo insuficiente para o saque de: {valor}')
        self.saldo -= valor

    def get_saldo(self):
        return self.saldo

if __name__ == '__main__':
    conta = ContaBancaria(100.0)

    try:
        conta.sacar(150.0)
    except SaldoInsuficienteException as e:
        print(e)
