class Carro:
    def __init__(self, modelo, marca, cor, ano):
        self._modelo = modelo
        self._marca = marca
        self._cor = cor
        self._ano = ano
        self._velocidade = 0

    def exibir_informacoes(self):
        return f"Modelo: {self._modelo}, Marca: {self._marca}, Cor: {self._cor}, Ano: {self._ano}"

    def acelerar(self):
        self._velocidade +=10
        print(self._modelo+" Acelerando...")
    def desacelerar(self):
        if self._velocidade >= 10:
            self._velocidade -=10
        else:
            self._velocidade = 0
        print(self._modelo+" Desacelerando...")
    def exibir_velocidade(self):
        return f"Velocidade: {self._velocidade}"


if __name__ == "__main__":
    carro1 = Carro("Civic", "Honda", "Preto", 2020)
    carro2 = Carro("Fusca", "Volkswagen", "Branco", 1976)
    carro3 = Carro("Model S", "Tesla", "Vermelho", 2022)

    print(carro1.exibir_informacoes())
    print(carro2.exibir_informacoes())
    print(carro3.exibir_informacoes())

    carro1.acelerar()
    carro1.acelerar()
    carro2.acelerar()
    carro2.desacelerar()
    carro3.acelerar()

    print(carro1.exibir_velocidade())
    print(carro2.exibir_velocidade())
    print(carro3.exibir_velocidade())