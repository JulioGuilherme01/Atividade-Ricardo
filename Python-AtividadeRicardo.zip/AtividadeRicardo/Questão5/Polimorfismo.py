class Animal:
    def som(self):
        pass

class Cachorro(Animal):
    def som(self):
        print("Au Au")

class Gato(Animal):
    def som(self):
        print("Miau")

def main():
    animais = [Cachorro(), Gato()]
    for animal in animais:
        animal.som()

if __name__ == "__main__":
    main()
