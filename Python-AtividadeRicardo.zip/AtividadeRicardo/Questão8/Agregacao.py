class Empresa:
    def __init__(self):
        self.empregados = []

    def adicionar_empregado(self, empregado):
        self.empregados.append(empregado)

class Empregado:
    def __init__(self, nome, cargo, salario):
        self.nome = nome
        self.cargo = cargo
        self.salario = salario
