class Funcionario:
    def calcular_salario(self):
        pass

class FuncionarioAssalariado(Funcionario):
    def __init__(self, salario_fixo):
        self.salario_fixo = salario_fixo

    def calcular_salario(self):
        return self.salario_fixo

class FuncionarioHorista(Funcionario):
    def __init__(self, horas_trabalhadas, valor_hora):
        self.horas_trabalhadas = horas_trabalhadas
        self.valor_hora = valor_hora

    def calcular_salario(self):
        return self.horas_trabalhadas * self.valor_hora

if __name__ == '__main__':
    f_assalariado = FuncionarioAssalariado(100)
    f_horista = FuncionarioHorista(7, 80)

    print(f_assalariado.calcular_salario())
    print(f_horista.calcular_salario())
