
class Animal:
    def som(self):
        pass


class Cachorro(Animal):
    def som(self):
        return "Au Au"


class Gato(Animal):
    def som(self):
        return "Miau"


def main():
    cachorro = Cachorro()
    gato = Gato()

    print("Cachorro faz:", cachorro.som())
    print("Gato faz:", gato.som())

if __name__ == "__main__":
    main()
