class Configuracao:
    _instancia = None

    def __new__(cls):
        if cls._instancia is None:
            cls._instancia = super(Configuracao, cls).__new__(cls)
            cls._instancia.configuracao = {}
        return cls._instancia

    def set_config(self, chave, valor):
        self.configuracao[chave] = valor

    def get_config(self, chave):
        return self.configuracao.get(chave)

if __name__ == '__main__':
    config1 = Configuracao()
    config1.set_config("url", "https://youtube.com")

    config2 = Configuracao()
    print(config2.get_config("url"))
    print(config1 is config2)
